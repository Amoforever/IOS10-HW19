import Cocoa

class Endpoint {
    
    let configuration = URLSessionConfiguration.default
    
    
    func makeUrlSessionWithTimeout(_ timeout: TimeInterval) -> URLSession {
        let configuration = URLSessionConfiguration.default
        configuration.allowsCellularAccess = true
        configuration.waitsForConnectivity = true
        configuration.timeoutIntervalForRequest = timeout
        configuration.httpMaximumConnectionsPerHost = 100
        configuration.urlCache = URLCache()
        var cache = URLCache()
        cache.cachedResponse(for: URLRequest(url: URL(string: "https://api.catboys.com/img")!))
        print("Кэш - \(cache )")
        
        return URLSession(configuration: configuration)
    }
    
    func getData(urlRequest: String) {
        let urlRequest = URLRequest(url: URL(string: "https://api.catboys.com/img")!)
        
        URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            // if error != nil {
            print("Ошибка -  \(error != nil)")
            if let response = response as? HTTPURLResponse, response.statusCode == 200 {
                print("Код ответа - \(response)")
                guard let data = data else { return }
                let dataAsString = String(describing: (String( data: data, encoding: .utf8)))
                print("Данные -  \(dataAsString)")
            }
        }.resume()
    }
    
    func errorHandling(connect: URLSessionConfiguration ) {
        let connect = configuration.allowsCellularAccess
        if connect == true {
            print("Возможна установка соединения по сотовой сети.")
        }else if connect != true {
            print("Установка соединения возможна только по Wi-Fi.")
        }
    }
}
    
    
    

    
    var endpoint = Endpoint()
    endpoint.getData(urlRequest: "https://api.catboys.com/img")
    endpoint.makeUrlSessionWithTimeout(30)
    endpoint.errorHandling(connect: endpoint.configuration )
